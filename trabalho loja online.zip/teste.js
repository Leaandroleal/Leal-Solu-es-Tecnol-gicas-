document.getElementById('aumentar').addEventListener('click', function() { //EventListener ocorre quando se precisa ouvir um evento, exemplo quando se clica no mouse, é um evento escutado.
    document.body.style.fontSize = '18px';
  });
  
  document.getElementById('diminuir').addEventListener('click', function() {
    document.body.style.fontSize = '14px';
  });